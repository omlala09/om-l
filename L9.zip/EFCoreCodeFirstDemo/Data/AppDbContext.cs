using EFCoreCodeFirstDemo.Models;
using Microsoft.EntityFrameworkCore;

namespace EFCoreCodeFirstDemo.Data
{
    // DbContext represents your database - it's a collection of DbSets,
    // the same way a database is a collection of tables.
    public class AppDbContext : DbContext
    {
        // Constructor chaining: this class takes DbContextOptions from the
        // framework (via dependency injection in Program.cs) and passes it
        // straight to the base DbContext constructor using "base(options)".
        // This is how AppDbContext knows which connection string to use.
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // Table names are conventionally plural.
        public DbSet<Product> Products { get; set; }
        public DbSet<Employee> Employees { get; set; }
    }
}
