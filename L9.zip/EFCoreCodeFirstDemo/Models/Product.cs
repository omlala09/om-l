using System.ComponentModel.DataAnnotations;

namespace EFCoreCodeFirstDemo.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = string.Empty;
    }
}
