using System.ComponentModel.DataAnnotations;

namespace EFCoreCodeFirstDemo.Models
{
    // Practice entity - same code-first pattern as Product, with a couple more
    // columns and a required field with validation to reinforce the concept.
    public class Employee
    {
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required]
        [MaxLength(50)]
        public string Department { get; set; } = string.Empty;

        public decimal Salary { get; set; }

        public DateTime JoiningDate { get; set; } = DateTime.UtcNow;
    }
}
