using EFCoreCodeFirstDemo.Data;
using EFCoreCodeFirstDemo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EFCoreCodeFirstDemo.Controllers
{
    // Practice example - same code-first CRUD pattern as ProductsController,
    // written manually to reinforce the concepts instead of relying on scaffolding.
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EmployeesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Employees
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Employee>>> GetAll()
        {
            return await _context.Employees.ToListAsync();
        }

        // GET: api/Employees/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Employee>> GetById(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null) return NotFound();
            return employee;
        }

        // GET: api/Employees/department/Engineering
        // Extra example query beyond the basic CRUD - filters with a LINQ Where().
        [HttpGet("department/{name}")]
        public async Task<ActionResult<IEnumerable<Employee>>> GetByDepartment(string name)
        {
            var employees = await _context.Employees
                .Where(e => e.Department.ToLower() == name.ToLower())
                .ToListAsync();

            return employees;
        }

        // POST: api/Employees
        [HttpPost]
        public async Task<ActionResult<Employee>> Create(Employee employee)
        {
            _context.Employees.Add(employee);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = employee.Id }, employee);
        }

        // PUT: api/Employees/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Employee updated)
        {
            if (id != updated.Id) return BadRequest();

            var exists = await _context.Employees.AnyAsync(e => e.Id == id);
            if (!exists) return NotFound();

            _context.Entry(updated).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/Employees/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var employee = await _context.Employees.FindAsync(id);
            if (employee == null) return NotFound();

            _context.Employees.Remove(employee);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
