# EF Core Code-First Demo (ASP.NET Core)

Companion code for the lecture on **Entity Framework Core — code-first workflow**: connection strings, `DbContext`, migrations, and CRUD APIs.

## Concepts covered

### 1. Connection string (`appsettings.json`)
Configuration values — including the DB connection — live in `appsettings.json` instead of being hardcoded, the same way a frontend app keeps secrets in a `.env` file.

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=YOUR_SERVER_NAME;Database=TrainingDB;Integrated Security=true;MultipleActiveResultSets=true;TrustServerCertificate=true"
}
```
- `Server` — which SQL Server instance to connect to
- `Database` — the database name
- `Integrated Security=true` — use Windows authentication (no user ID/password). Set to `false` and add `User Id=...;Password=...` for SQL Server authentication instead.
- `MultipleActiveResultSets=true` — lets the app run multiple async queries over one connection at the same time
- `TrustServerCertificate=true` — needed when SQL Server uses a self-signed SSL/TLS certificate locally

### 2. `DbContext` and constructor chaining
```csharp
public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Product> Products { get; set; }
    public DbSet<Employee> Employees { get; set; }
}
```
`AppDbContext` inherits `DbContext`, whose constructor requires a `DbContextOptions` object. Because you're inheriting a class with a parameterized constructor, you must chain into it with `: base(options)` — this is **constructor chaining**: the framework hands `options` (built from your connection string) to your derived class, which passes it straight up to the base class.

### 3. Registering the context (`Program.cs`)
```csharp
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");
builder.Services.AddDbContext<AppDbContext>(options => options.UseSqlServer(connectionString));
```
This both reads the connection string and registers `AppDbContext` with the DI container, so any controller can receive it via constructor injection.

### 4. Code-first vs database-first
- **Code-first** (used here): you write the C# model classes and `DbContext`; EF Core generates the SQL to create/alter the actual tables via migrations.
- **Database-first**: the database and tables already exist; you scaffold C# model classes *from* the existing schema instead.

### 5. Migrations (Package Manager Console)
```powershell
Add-Migration InitialCreate     # generates a C# file describing the schema change
Update-Database                 # applies it, creating/altering real tables in SQL Server
Remove-Migration                # undoes the last migration if it hasn't been applied yet
```
Applied migrations are tracked in a table EF Core creates automatically, `__EFMigrationsHistory`, so it knows what's already been applied.

### 6. Scaffolded CRUD controller
Visual Studio can generate a full CRUD controller from a model + DbContext ("Add Controller → API controller with actions, using Entity Framework"). It produces `GetProducts`, `GetProduct(id)`, `PutProduct`, `PostProduct`, `DeleteProduct`, using:
- `ToListAsync()` — get all rows
- `FindAsync(id)` — get one row by primary key
- `SaveChangesAsync()` — commit changes to the database
- A `ProductExists()` helper to check before updating

See `Controllers/ProductsController.cs` for this exact pattern.

## Worked example: `Employee` entity

To practice the same workflow independently, this repo also includes a second entity, **hand-written rather than scaffolded**, so you can compare both approaches side by side.

**`Models/Employee.cs`** — a slightly richer model with validation attributes:
```csharp
public class Employee
{
    public int Id { get; set; }

    [Required, MaxLength(100)]
    public string Name { get; set; } = string.Empty;

    [Required, MaxLength(50)]
    public string Department { get; set; } = string.Empty;

    public decimal Salary { get; set; }
    public DateTime JoiningDate { get; set; } = DateTime.UtcNow;
}
```

**`Controllers/EmployeesController.cs`** implements the standard CRUD (`GetAll`, `GetById`, `Create`, `Update`, `Delete`) plus one extra query beyond the basics — filtering by department using LINQ's `Where()`:
```csharp
[HttpGet("department/{name}")]
public async Task<ActionResult<IEnumerable<Employee>>> GetByDepartment(string name)
{
    return await _context.Employees
        .Where(e => e.Department.ToLower() == name.ToLower())
        .ToListAsync();
}
```

Try extending this yourself as more practice:
- Add a `GET api/employees/highest-paid` endpoint that returns the employee with `OrderByDescending(e => e.Salary).FirstOrDefaultAsync()`
- Add a `Manager` model with a foreign key to `Employee` and explore EF Core relationships (`.Include()`)

## Project structure

```
EFCoreCodeFirstDemo/
├── Models/
│   ├── Product.cs
│   └── Employee.cs        (practice example)
├── Data/
│   └── AppDbContext.cs
├── Controllers/
│   ├── ProductsController.cs      (scaffolded-style, from the lecture)
│   └── EmployeesController.cs     (hand-written practice example)
├── Program.cs
├── appsettings.json
└── EFCoreCodeFirstDemo.csproj
```

## Running it locally

Requires the [.NET 8 SDK](https://dotnet.microsoft.com/download) and SQL Server (local or Azure).

```bash
cd EFCoreCodeFirstDemo
dotnet restore
```

1. Update `appsettings.json` with your actual server name and, if not using Windows auth, `User Id`/`Password`.
2. Install the EF Core CLI tool once, if you haven't:
   ```bash
   dotnet tool install --global dotnet-ef
   ```
3. Create and apply the migration:
   ```bash
   dotnet ef migrations add InitialCreate
   dotnet ef database update
   ```
4. Run the app:
   ```bash
   dotnet run
   ```
5. Open `/swagger` to try the endpoints, or hit them directly:
   - `GET /api/products`, `POST /api/products`, etc.
   - `GET /api/employees`, `GET /api/employees/department/Engineering`, etc.

## Pushing to GitHub

```bash
git init
git add .
git commit -m "EF Core code-first demo: Product + Employee CRUD"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```
Consider adding a `.gitignore` for `bin/`, `obj/`, and `.vs/` before your first commit (a standard Visual Studio `.gitignore` from GitHub's templates works well).

## Note

Written and reviewed carefully but not compiled in this environment (no .NET SDK available here). Run `dotnet build` locally and resolve any environment-specific issues (SDK/package versions, your actual SQL Server name) before relying on it.
